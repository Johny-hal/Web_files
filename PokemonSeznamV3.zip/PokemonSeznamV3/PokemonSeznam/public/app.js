
async function api(path, options) {
  console.log(`API call: ${options.method} ${path}`);
  
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  
  const ct = res.headers.get("content-type") || "";
  const data = ct.includes("application/json") ? await res.json() : await res.text();
  
  console.log(`API response: ${res.status}`, data);
  
  if (!res.ok) throw { status: res.status, data };
  return data;
}







async function api(path, options) {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const ct = res.headers.get("content-type") || "";
  const data = ct.includes("application/json") ? await res.json() : await res.text();
  if (!res.ok) throw { status: res.status, data };
  return data;
}


// Pomocná funkce pro fetch z PokeAPI
async function fetchPokemon(pokemonId) {
  try {
    const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonId}/`);

    if (!response.ok) throw new Error('Pokémon nenalezen');
    return await response.json();
  } catch (error) {
    console.error('Chyba při načítání Pokémona:', error);
    throw error;
  }
}

// CREATE (POST /api/pokemons)
const createForm = document.getElementById("createForm");
if (createForm) {
  createForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(createForm);
    const pokemonId = fd.get("pokemonId");

    const msg = document.getElementById("createMsg");
    try {
      // Fetch z PokeAPI
      const pokemonData = await fetchPokemon(pokemonId);
      
      // Uložení do naší databáze
      const payload = {
        name: pokemonData.name,
        sprite: pokemonData.sprites.front_default,
        types: pokemonData.types.map(t => t.type.name).join(', ')
      };
      
      await api("/api/pokemons", { 
        method: "POST", 
        body: JSON.stringify(payload) 
      });
      window.location.reload();
    } catch (err) {
      msg.textContent = "Chyba: " + (err.data?.error || err.message);
    }
  });
}

// EDIT (PUT /api/pokemons/:id)
const editForm = document.getElementById("editForm");
if (editForm) {
  editForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = editForm.dataset.id;
    const fd = new FormData(editForm);
    const pokemonId = fd.get("pokemonId");

    const msg = document.getElementById("editMsg");
    try {
      // Fetch nových dat z PokeAPI
      const pokemonData = await fetchPokemon(pokemonId);
      
      const payload = {
        name: pokemonData.name,
        sprite: pokemonData.sprites.front_default,
        types: pokemonData.types.map(t => t.type.name).join(', ')
      };

      await api(`/api/pokemons/${id}`, { 
        method: "PUT", 
        body: JSON.stringify(payload) 
      });
      window.location.href = `/pokemon/${id}`;
    } catch (err) {
      msg.textContent = "Chyba: " + (err.data?.error || err.message);
    }
  });
}

// DELETE tlačítka (DELETE /api/pokemons/:id)
document.addEventListener("click", async (e) => {
  const btn = e.target.closest("[data-delete-id]");
  if (!btn) return;

  const id = btn.dataset.deleteId;
  if (!confirm("Opravdu smazat Pokémona #" + id + "?")) return;

  try {
    await api(`/api/pokemons/${id}`, { method: "DELETE" });
    window.location.href = "/";
  } catch (err) {
    alert("Chyba: " + JSON.stringify(err.data));
  }
});




// Automatické načtení Pokémona při editaci (pokud existuje pole pro ID)
const pokemonIdInput = document.getElementById("pokemonId");
if (pokemonIdInput && pokemonIdInput.dataset.preview) {
  pokemonIdInput.addEventListener("change", async (e) => {
    const preview = document.getElementById("pokemonPreview");
    if (!preview) return;
    
    const id = e.target.value;
    if (!id || id < 1 || id > 1010) {
      preview.innerHTML = "<p>Zadejte ID mezi 1-1010</p>";
      return;
    }
    
    try {
      const pokemonData = await fetchPokemon(id);
      preview.innerHTML = `
        <div style="border: 1px solid #ccc; padding: 10px; margin: 10px 0;">
          <img src="${pokemonData.sprites.front_default}" alt="${pokemonData.name}" />
          <h3>${pokemonData.name}</h3>
          <p>Typ: ${pokemonData.types.map(t => t.type.name).join(', ')}</p>
        </div>
      `;
    } catch (error) {
      preview.innerHTML = `<p style="color: red;">Pokémon nenalezen</p>`;
    }
  });
}


/* Vzal jsem to z index html abych to měl vše na jednom místě */

let PokeSearchs = document.getElementById("PokeSearchs")
let suggestionBox = document.getElementById("suggestionBox")
let Lipokemon = document.getElementById("Lipokemon")


// Načíst seznam Pokémonů při startu
let pokemonList = [];

async function loadPokemonList() {
  /*Tuto funkci pomohlo AI bez toho mi to hazelo errory na každém kroky, + jsem nevěděl že mužu zadat limit rovnou do url stránky*/
    const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=1000');
    const data = await response.json();
    
    pokemonList = data.results.map((p, i) => ({
      id: i + 1,
      name: p.name.toLowerCase(),
    }));
    console.log('Načteno Pokémonů:', pokemonList.length);
 
  
}

function Pokesearching() {
  let pokemon = PokeSearchs.value.toLowerCase().trim();
  
  if (pokemon.length < 2) {
    suggestionBox.style.display = "none";
    return;
  }
  
  // Oprava: správný název proměnné
  const results = pokemonList.filter(p =>
    p.name.includes(pokemon) || p.id.toString().includes(pokemon)
  ).slice(0, 5);
/*přidan onlick + naučil jsem se při opravě chyb '' tyto uvozovky protože p.name mi davalo chyby, hlavně p.name davalo error vůli tomu*/
  if (results.length > 0) {
    suggestionBox.innerHTML = `
      <ul style="list-style:none;margin:0;padding:0;margin-bottom:100px;">
        ${results.map(p => `
          <li 
          document.getElementById('suggestionBox').style.display='none'" id="Lipokemon">
            #<span onclick="PokeSearchs.value = '${p.id}'";> ${p.id} </span> <span onclick="PokeSearchs.value = '${p.name}'"> ${p.name} </span> 
            <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${p.id}.png""
           alt="${p.name}" 
           id="Ulsprite" />
          </li>
        `).join('')}
      </ul>
    `;
    suggestionBox.style.display = 'block';
  } else {
    suggestionBox.style.display = 'none';
  }
}

// Přidat event listener až po načtení
document.addEventListener('DOMContentLoaded', function() {
  PokeSearchs.addEventListener("input", Pokesearching);
  
  // Načíst seznam
  loadPokemonList();

});


  /*Z nějaaého duvodu mi blbo searchbar když jsem dal src na app.js tak jinčí script to je*/
  document.getElementById('searchbar').addEventListener('keyup', function() {
    searchTable();
  });
  function searchTable() {
    const input = document.getElementById('searchbar');
    const filter = input.value.toUpperCase();
    const table = document.getElementById('table');
    const rows = table.rows;
    var hasResult = false;
    for (let i = 1; i < rows.length; i++) {
      const cells = rows[i].getElementsByTagName('td');
      let found = false;
      
      
      for (let j = 0; j < cells.length; j++) {
        const cellText = cells[j].textContent || cells[j].innerText;
        if (cellText.toUpperCase().indexOf(filter) > -1) {
          found = true;
          hasResult = true;
          break;
        }
      }
      rows[i].style.display = found ? '' : 'none';
    }
    
    
  }


// Přidana funkce z jinčího projektu ale bude určitě změněna (cca 9-10.2)
function sortTable(n) {
            let table;
            table = document.getElementById("table");
            var rows, i, x, y, count = 0;
            var switching = true;

            // Order is set as ascending
            var direction = "ascending";

            // Run loop until no switching is needed
            while (switching) {
                switching = false;
                var rows = table.rows;

                //Loop to go through all rows
                for (i = 1; i < (rows.length - 1); i++) {
                    var Switch = false;

                    // Fetch 2 elements that need to be compared
                    x = rows[i].getElementsByTagName("TD")[n];
                    y = rows[i + 1].getElementsByTagName("TD")[n];

                    // Check the direction of order
                    if (direction == "ascending") {

                        // Check if 2 rows need to be switched
                        if (x.innerHTML.toLowerCase() >
                            y.innerHTML.toLowerCase()) {

                            // If yes, mark Switch as needed 
                            // and break loop
                            Switch = true;
                            break;
                        }
                    } else if (direction == "descending") {

                        // Check direction
                        if (x.innerHTML.toLowerCase() <
                            y.innerHTML.toLowerCase()) {

                            // If yes, mark Switch as needed
                            // and break loop
                            Switch = true;
                            break;
                        }
                    }
                }
                if (Switch) {

                    // Function to switch rows and mark 
                    // switch as completed
                    rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                    switching = true;

                    // Increase count for each switch
                    count++;
                } else {

                    // Znova pro klesajici (10,9,8 atd)
                    if (count == 0 && direction == "ascending") {
                        direction = "descending";
                        switching = true;
                    }
                }
            }
        }