const store = require("../storage/pokemonsStore");

function readBodyJson(req, cb) {
  let body = "";
  req.on("data", (ch) => (body += ch));
  req.on("end", () => {
    try {
      cb(null, JSON.parse(body || "{}"));
    } catch (e) {
      cb(e);
    }
  });
}

function sendJson(res, status, data) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
}

function handleApiPokemons(req, res) {
  console.log(`${req.method} ${req.url}`);
  
  // GET /api/pokemons – vrátí všechny Pokémony
  if (req.url === "/api/pokemons" && req.method === "GET") {
    const pokemons = store.getAll();
    console.log(`Vracím ${pokemons.length} Pokémonů`);
    return sendJson(res, 200, pokemons);
  }

  // POST /api/pokemons
  if (req.url === "/api/pokemons" && req.method === "POST") {
    return readBodyJson(req, (err, data) => {
      if (err) {
        console.error("Chyba JSON:", err);
        return sendJson(res, 400, { error: "Neplatný JSON" });
      }

      console.log("POST data:", data);
      
      const name = String(data.name || "").trim();
      const sprite = String(data.sprite || "");
      const types = String(data.types || "");

      if (!name) {
        console.error("Chybí název Pokémona");
        return sendJson(res, 400, { error: "Chybí název Pokémona" });
      }

      try {
        const created = store.create({ name, sprite, types });
        console.log("Vytvořen Pokémon:", created);
        return sendJson(res, 201, created);
      } catch (createErr) {
        console.error("Chyba při vytváření:", createErr);
        return sendJson(res, 500, { error: "Interní chyba serveru" });
      }
    });
  }

  // PUT /api/pokemons/:id
  if (req.url.startsWith("/api/pokemons/") && req.method === "PUT") {
    const id = Number(req.url.split("/")[3]);
    if (Number.isNaN(id)) return sendJson(res, 400, { error: "Neplatné ID" });

    console.log(`PUT pokemon/${id}`);
    
    return readBodyJson(req, (err, data) => {
      if (err) return sendJson(res, 400, { error: "Neplatný JSON" });

      const patch = {};
      if (data.name !== undefined) patch.name = String(data.name).trim();
      if (data.sprite !== undefined) patch.sprite = String(data.sprite);
      if (data.types !== undefined) patch.types = String(data.types);

      console.log("Update patch:", patch);
      
      const updated = store.update(id, patch);
      if (!updated) {
        console.error(`Pokémon ${id} nenalezen pro update`);
        return sendJson(res, 404, { error: "Pokémon nenalezen" });
      }

      console.log("Updated Pokémon:", updated);
      return sendJson(res, 200, updated);
    });
  }

  // DELETE /api/pokemons/:id
  if (req.url.startsWith("/api/pokemons/") && req.method === "DELETE") {
    const id = Number(req.url.split("/")[3]);
    if (Number.isNaN(id)) return sendJson(res, 400, { error: "Neplatné ID" });

    console.log(`DELETE pokemon/${id}`);
    
    const removed = store.remove(id);
    if (!removed) {
      console.error(`Pokémon ${id} nenalezen pro smazání`);
      return sendJson(res, 404, { error: "Pokémon nenalezen" });
    }

    console.log("Smazán Pokémon:", removed);
    return sendJson(res, 200, { message: "Pokémon smazán", pokemon: removed });
  }

  return false; // neobslouženo
}

module.exports = { handleApiPokemons };