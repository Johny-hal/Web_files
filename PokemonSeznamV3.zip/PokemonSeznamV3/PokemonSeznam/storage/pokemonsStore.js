const fs = require("fs");
const path = require("path");

const POKEMONS_FILE = path.join(__dirname, "..", "data", "pokemons.json");

function loadPokemons() {
  try {
    const raw = fs.readFileSync(POKEMONS_FILE, "utf-8");
    const data = JSON.parse(raw);

    if (!Array.isArray(data)) {
      return [];
    }
    return data;
  } catch (e) {
    console.log("❌ Chyba při čtení/parsu pokemons.json:", e.message);
    return [];
  }
}

function savePokemons(pokemons) {
  fs.writeFileSync(POKEMONS_FILE, JSON.stringify(pokemons, null, 2), "utf-8");
}

function getAll() {
  return loadPokemons();
}

function getById(id) {
  const pokemons = loadPokemons();
  // Ujistěte se, že porovnáváme čísla s čísly
  return pokemons.find((p) => Number(p.id) === Number(id)) || null;
}

function create({ name, sprite, types }) {
  const pokemons = loadPokemons();
  
  // Najdi nejvyšší ID - opravená logika
  const newId = pokemons.length > 0 
    ? Math.max(...pokemons.map((p) => Number(p.id || 0))) + 1 
    : 1;
    
  const pokemon = { 
    id: newId, 
    name: String(name || "").trim(), 
    sprite: String(sprite || ""), 
    types: String(types || "") 
  };
  
  pokemons.push(pokemon);
  savePokemons(pokemons);
  
  console.log(`Vytvořen Pokémon #${newId}: ${pokemon.name}`);
  return pokemon;
}

function update(id, patch) {
  const pokemons = loadPokemons();
  const idx = pokemons.findIndex((p) => Number(p.id) === Number(id));
  if (idx === -1) return null;

  if (patch.name !== undefined) pokemons[idx].name = String(patch.name).trim();
  if (patch.sprite !== undefined) pokemons[idx].sprite = String(patch.sprite);
  if (patch.types !== undefined) pokemons[idx].types = String(patch.types);

  savePokemons(pokemons);
  return pokemons[idx];
}

function remove(id) {
  const pokemons = loadPokemons();
  const idx = pokemons.findIndex((p) => Number(p.id) === Number(id));
  if (idx === -1) return null;
  const removed = pokemons.splice(idx, 1)[0];
  savePokemons(pokemons);
  return removed;
}

module.exports = { getAll, getById, create, update, remove };