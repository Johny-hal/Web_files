const fs = require("fs");
const path = require("path");
const store = require("../storage/pokemonsStore");

const VIEWS_DIR = path.join(__dirname, "..", "views");

function loadView(name) {
  return fs.readFileSync(path.join(VIEWS_DIR, name), "utf-8");
}

function render(template, vars) {
  let out = template;
  for (const [k, v] of Object.entries(vars)) {
    // Zajistíme, že null/undefined se zobrazí jako prázdný řetězec
    out = out.replaceAll(`{{${k}}}`, v !== null && v !== undefined ? String(v) : "");
  }
  return out;
}

function renderLayout({ title, heading, content }) {
  const layout = loadView("layout.html");
  return render(layout, { title, heading, content });
}

function sendHtml(res, html, status = 200) {
  res.writeHead(status, { "Content-Type": "text/html; charset=utf-8" });
  res.end(html);
}

function handlePages(req, res) {
  // GET /public/app.js
  if (req.url === "/public/app.js" && req.method === "GET") {
    const file = path.join(__dirname, "..", "public", "app.js");
    const js = fs.readFileSync(file, "utf-8");
    res.writeHead(200, { "Content-Type": "application/javascript; charset=utf-8" });
    return res.end(js);
  }

  // GET /
  if (req.url === "/" && req.method === "GET") {
    const pokemons = store.getAll();
    
    // DEBUG: vypiš obsah pro kontrolu
    console.log("Načtení Pokémonů:", JSON.stringify(pokemons, null, 2));

    const rows = pokemons.map(p => {
      // Ujistíme se, že máme všechny potřebné hodnoty
      const id = p.id || "N/A";
      const name = p.name || "Bez názvu";
      const sprite = p.sprite || "";
      const types = p.types || "Neznámý typ";
      
      return `
      <tr>
        <td>${id}</td>
        <td>
          ${sprite ? `<img src="${sprite}" alt="${name}" style="height: 50px; vertical-align: middle;" />` : ''}
          <a href="/pokemon/${id}">${name}</a>
        </td>
        <td>${types}</td>
        <td>
          <a href="/pokemon/${id}">Detail</a>
          <a href="/edit/${id}">Upravit</a>
          <button data-delete-id="${id}">Smazat</button>
        </td>
      </tr>
    `}).join("");

    const indexTpl = loadView("index.html");
    const content = render(indexTpl, {
      rows: rows || `<tr><td colspan="4">Žádní Pokémoni.</td></tr>`
    });

    return sendHtml(
      res,
      renderLayout({
        title: "Pokémoni",
        heading: "Správa Pokémonů",
        content
      })
    );
  }

  // GET /pokemon/:id (detail)
  if (req.url.startsWith("/pokemon/") && req.method === "GET") {
    const id = Number(req.url.split("/")[2]);
    console.log(`Hledám Pokémona s ID: ${id}`);
    
    const pokemon = store.getById(id);
    
    if (!pokemon) {
      console.log(`Pokémon s ID ${id} nenalezen`);
      const errTpl = loadView("error.html");
      const content = render(errTpl, { message: "Pokémon nenalezen." });
      return sendHtml(res, renderLayout({ title: "Chyba", heading: "Chyba", content }), 404);
    }

    console.log(`Nalezen Pokémon:`, pokemon);
    const tpl = loadView("detail.html");
    const content = render(tpl, pokemon);
    return sendHtml(res, renderLayout({ 
      title: "Detail", 
      heading: `Detail Pokémona: ${pokemon.name}`,
      content 
    }));
  }

  // GET /edit/:id (edit formulář)
  if (req.url.startsWith("/edit/") && req.method === "GET") {
    const id = Number(req.url.split("/")[2]);
    const pokemon = store.getById(id);

    if (!pokemon) {
      const errTpl = loadView("error.html");
      const content = render(errTpl, { message: "Pokémon nenalezen." });
      return sendHtml(res, renderLayout({ title: "Chyba", heading: "Chyba", content }), 404);
    }

    const tpl = loadView("edit.html");
    const content = render(tpl, pokemon);
    return sendHtml(res, renderLayout({ 
      title: "Editace", 
      heading: `Editace Pokémona: ${pokemon.name}`,
      content 
    }));
  }

  return false;
}

module.exports = { handlePages };