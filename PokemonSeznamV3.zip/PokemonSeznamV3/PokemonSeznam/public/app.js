
async function api(path, options) {
  console.log(`API call: ${options.method} ${path}`);
  
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  
  const ct = res.headers.get("content-type") || "";
  const data = ct.includes("application/json") ? await res.json() : await res.text();
  
  console.log(`API response: ${res.status}`, data);
  
  if (!res.ok) throw { status: res.status, data };
  return data;
}







async function api(path, options) {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const ct = res.headers.get("content-type") || "";
  const data = ct.includes("application/json") ? await res.json() : await res.text();
  if (!res.ok) throw { status: res.status, data };
  return data;
}


// Pomocná funkce pro fetch z PokeAPI
async function fetchPokemon(pokemonId) {
  try {
    const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonId}/`);

    if (!response.ok) throw new Error('Pokémon nenalezen');
    return await response.json();
  } catch (error) {
    console.error('Chyba při načítání Pokémona:', error);
    throw error;
  }
}

// CREATE (POST /api/pokemons)
const createForm = document.getElementById("createForm");
if (createForm) {
  createForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(createForm);
    const pokemonId = fd.get("pokemonId");

    const msg = document.getElementById("createMsg");
    try {
      // Fetch z PokeAPI
      const pokemonData = await fetchPokemon(pokemonId);
      
      // Uložení do naší databáze
      const payload = {
        name: pokemonData.name,
        sprite: pokemonData.sprites.front_default,
        types: pokemonData.types.map(t => t.type.name).join(', ')
      };
      
      await api("/api/pokemons", { 
        method: "POST", 
        body: JSON.stringify(payload) 
      });
      window.location.reload();
    } catch (err) {
      msg.textContent = "Chyba: " + (err.data?.error || err.message);
    }
  });
}

// EDIT (PUT /api/pokemons/:id)
const editForm = document.getElementById("editForm");
if (editForm) {
  editForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = editForm.dataset.id;
    const fd = new FormData(editForm);
    const pokemonId = fd.get("pokemonId");

    const msg = document.getElementById("editMsg");
    try {
      // Fetch nových dat z PokeAPI
      const pokemonData = await fetchPokemon(pokemonId);
      
      const payload = {
        name: pokemonData.name,
        sprite: pokemonData.sprites.front_default,
        types: pokemonData.types.map(t => t.type.name).join(', ')
      };

      await api(`/api/pokemons/${id}`, { 
        method: "PUT", 
        body: JSON.stringify(payload) 
      });
      window.location.href = `/pokemon/${id}`;
    } catch (err) {
      msg.textContent = "Chyba: " + (err.data?.error || err.message);
    }
  });
}

// DELETE tlačítka (DELETE /api/pokemons/:id)
document.addEventListener("click", async (e) => {
  const btn = e.target.closest("[data-delete-id]");
  if (!btn) return;

  const id = btn.dataset.deleteId;
  if (!confirm("Opravdu smazat Pokémona #" + id + "?")) return;

  try {
    await api(`/api/pokemons/${id}`, { method: "DELETE" });
    window.location.href = "/";
  } catch (err) {
    alert("Chyba: " + JSON.stringify(err.data));
  }
});

// Automatické načtení Pokémona při editaci (pokud existuje pole pro ID)
const pokemonIdInput = document.getElementById("pokemonId");
if (pokemonIdInput && pokemonIdInput.dataset.preview) {
  pokemonIdInput.addEventListener("change", async (e) => {
    const preview = document.getElementById("pokemonPreview");
    if (!preview) return;
    
    const id = e.target.value;
    if (!id || id < 1 || id > 1010) {
      preview.innerHTML = "<p>Zadejte ID mezi 1-1010</p>";
      return;
    }
    
    try {
      const pokemonData = await fetchPokemon(id);
      preview.innerHTML = `
        <div style="border: 1px solid #ccc; padding: 10px; margin: 10px 0;">
          <img src="${pokemonData.sprites.front_default}" alt="${pokemonData.name}" />
          <h3>${pokemonData.name}</h3>
          <p>Typ: ${pokemonData.types.map(t => t.type.name).join(', ')}</p>
        </div>
      `;
    } catch (error) {
      preview.innerHTML = `<p style="color: red;">Pokémon nenalezen</p>`;
    }
  });
}